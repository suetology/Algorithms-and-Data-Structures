# ADS 2 laboratorinis darbas, 3 užduotis

Pagrindinis kodas yra main.cpp faile, testų duomenis yra failuose test1.txt, test2.txt, test3.txt

Tam, kad sukompiliuoti programą ir išbandyti testus reikia paleisti run_tests.bat failą ir tada rezultatai atsiras tests_output.txt faile